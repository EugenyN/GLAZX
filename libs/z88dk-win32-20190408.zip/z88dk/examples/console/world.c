/*
 *	Hello World
 */


#include <stdio.h>


main()
{
	printf("Hello world! %d\n",12);
	fgetc_cons();
}
