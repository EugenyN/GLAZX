#ifndef _LEVEL_SCREEN_H_
#define _LEVEL_SCREEN_H_

#define EASY_SIDE	9
#define HARD_SIDE	18

void screen_level_screen_load();
void screen_level_screen_update(int *screen_type, int curr_joypad1, int prev_joypad1);

#endif//_LEVEL_SCREEN_H_
