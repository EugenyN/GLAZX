#include <stdio.h>

void main() {
  unsigned char a;
  while (1) {
    a = getk();
    /* fputs("a",stdout); */
    printf("%u\n", a);
  }

}
