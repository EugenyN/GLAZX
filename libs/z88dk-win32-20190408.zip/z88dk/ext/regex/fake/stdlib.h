extern char *malloc();
extern char *realloc();
